export default async function NotFound() {
  return <h1>Page not found</h1>;
}
