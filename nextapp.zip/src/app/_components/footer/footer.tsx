export const Footer: React.FC = () => {
  return (
    <footer className="dark:bg-base-200">
      <p>footer</p>
    </footer>
  );
};
