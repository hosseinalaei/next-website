"use client";

export default function Error() {
  return <h1>Page error</h1>;
}
