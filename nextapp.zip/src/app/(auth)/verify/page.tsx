export default async function Verify() {
  return (
    <div className="text-5xl flex justify-center items-center">
      <h1>this is Verify page</h1>;
    </div>
  );
}
