export default async function Cources() {
  return <h1>this is Cources page</h1>;
}
