import Image from "next/image";
import { Colors } from "./_components/colors/colors";

export default function Home() {
  return <div className="text-purple-700">Next App</div>;
}
