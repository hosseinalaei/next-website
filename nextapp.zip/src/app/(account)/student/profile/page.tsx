export default async function Profile() {
  return <h1>this is profile page</h1>;
}
