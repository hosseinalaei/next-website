export default async function Blog() {
  return <h1>this is b;og page</h1>;
}
